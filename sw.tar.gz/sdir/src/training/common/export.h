#pragma once

#ifdef CMAKE_BUILD
#  include <common_training_export.h>
#endif
